clear
num = input("Digite um número inteiro positivo: ");
sequencia = fibonacci(num)

