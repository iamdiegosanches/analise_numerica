clear
n1 = input("Digite o primeiro valor: ");
n2 = input("Digite o segundo valor: ");

if n1 > n2
    fprintf("O maior número é: %f\n", n1);
elseif n2 > n1
    fprintf("O maior número é: %f\n", n2);
else
    fprintf("Os números são iguais.\n");
endif


