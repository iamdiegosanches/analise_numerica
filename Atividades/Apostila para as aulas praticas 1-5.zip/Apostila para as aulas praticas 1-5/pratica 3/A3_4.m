clear
# Resolucao exercicio 3.4

A = [3 1 4; 8 1 2; 2 5 6];
b = [0 0 0]
[A, b, Det, Info] = eliminacao_gauss (3, A, b)

B = [-10 2 4 6; 5 -8 4 1; 3 9 12 5; -4 0 5 2];
b = [0 0 0 0]
[B, b, Det, Info] = eliminacao_gauss (4, B, b)
