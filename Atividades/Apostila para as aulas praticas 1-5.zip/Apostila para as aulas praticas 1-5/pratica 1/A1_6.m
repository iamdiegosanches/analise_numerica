clear
clc

# a)

resa = seno(2,6)

# b)

resb = sin(2)

# c)
erro = resa - resb

ordem_erro = erro/resa
