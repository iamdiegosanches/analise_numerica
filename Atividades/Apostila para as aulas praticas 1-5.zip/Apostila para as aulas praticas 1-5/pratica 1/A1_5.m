clear
clc
# a)

format short
res = (sqrt(5) + 3)/0.3541

# b)

format bank
valor = (e^3+log(5))/(sin(3)+tan(0.5))

# c)

format bank
res = log(5)/log(3)

# d)

format short
res = (3.16)^(1/3)

