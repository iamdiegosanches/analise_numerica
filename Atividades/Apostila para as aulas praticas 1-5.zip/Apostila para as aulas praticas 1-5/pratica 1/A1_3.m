clear
# Atividade 1.3

# letra A
carbono = [0.5 1 0.1; 3 5 0.3; 4 7 0.8];
trator = [20; 30; 5];
resultado = carbono' * trator;
disp(resultado);

# letra B
valores = [5; 20; 15];
resultadob = resultado'*valores

# letra C

resultadoc = carbono*valores

