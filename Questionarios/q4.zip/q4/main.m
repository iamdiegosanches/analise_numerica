clear
clc

f = @(x) (5.*sin(x.^9)*6.*x.^6+2.*(x.^10)*2.*x.^7);

a = -2.94;
b = -2.68;
n = 4;
[Integ, Info] = gauss_legendre (a, b, n, f)