clear 
clc

f = @(x) (2.*x.^2*7.*x.^3+1*(x.^4).*2.*exp(x.^7));
a = -4.30;
b = -1.40;
n = 2;
m = 6;


[Integral, Info] = newton_cotes (a, b, n, m, f)