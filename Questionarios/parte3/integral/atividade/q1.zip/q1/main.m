clear
clc

f = @(x, y) (3.0*x.^10.0*9.0*y.^4.0+3.0*y.^2.0+6.0*y.^10.0);


ax = -4.29;
bx = -2.37;
mx = 6;
nx = 3;

ay = -0.18;
by = -1.20;
my = 6;
ny = 1;



[Integral, Info] = newton_cotes_dupla (ax, bx, nx, mx, ay, by, ny, my, f)