clear
clc

f = @(x) (8*sin(240*pi*x));

a = 0;
b = 0.25/60;
n = 5;


[Integ, Info] = gauss_legendre (a, b, n, f)