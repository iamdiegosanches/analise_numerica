clear
clc

m = input('Entre com uma matriz mxn: ');

grafico_funcs(m);