clear
clc

# dV/dt = 0.6*sin(80*pi*t)
# dV = 0.6*sin(80*pi*t)dt

f = @(t)(0.6*sin(80*pi*t));

a = 0;
b = 5;
n = 6;

[Integ, Info] = gauss_legendre (a, b, n, f);

disp('A quantidade de ar inalada sera: ');
ar = Integ