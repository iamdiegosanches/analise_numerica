clear
clc

f = @(x) (3.0*cos(x^8.0)*+9.0*cos(x^5.0))
Toler = 10^(-3);
IterMax = 10;
a = -1.25;
b = -1.15;

printf('Secante\n');
[Raiz, Iter, Info] = secante (a, b, Toler, IterMax, f)
disp('Raiz calculada esta fora do intervalo');

printf('\nRegula falsi\n');
[Raiz, Iter, Info] = regula_falsi (a, b, Toler, IterMax, f)

printf('\nPegaso\n');
[Raiz, Iter, Info] = pegaso (a, b, Toler, IterMax, f)