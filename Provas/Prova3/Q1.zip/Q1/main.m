clear
clc

f = @(x,y)(1.0*cos(x^7.0)*10.0*cos(y^2.0) + 2.0*x^2.0 + 8.0*cos(x^5.0));

y0 = -0.13;
a = -0.96;
b = 0.71;
m = 100;

[VetX, VetY] = Euler (a, b, y0, m, f);
VetX = VetX'
VetY = VetY'