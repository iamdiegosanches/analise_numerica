clear
clc


f = @(x) (9*sin(x^8)*+3*cos(x^4)+7*(x^3)*+7*sin(x^5));

a = -4.36;
b = -0.43;
n = 3;

[Integ, Info] = gauss_legendre (a, b, n, f)