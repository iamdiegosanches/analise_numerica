clear
clc

# necessario encontrar quanto vale r
# dQ/dt = -rQ
# dQ/Q = -rdt
# ln Q = -rt + C
# Q = exp(-rt)*C
# Q(0) = exp(0)*C
C = 100
# Q(30) = exp(-k*30)*100 = 82.04
# exp(-r*30) = 82.04/100
# -r*30 = ln(82.04/C)

r = (-1)*log(82.04/C)/30

f = @(Q, t) (-r*Q);

y0 = 100;
a = 0;
b = 0.01;
m = 20;

# Encontrando o valor de b para quando a massa e metade da massa original
while 1
  [VetX, VetY] = Euler (a, b, y0, m, f);
  if VetY(end) <= 50
    break;
  else
    b = b + 0.01;
  endif
endwhile

fprintf('\n Sao necessarios %.2f dias para chegar a metade da massa\n', b);